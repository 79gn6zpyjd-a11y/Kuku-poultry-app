export default function App() {
  const services = [
    {
      title: "Poultry Farmers",
      text: "Connect farmers to suppliers, buyers and poultry experts."
    },
    {
      title: "Feeds Marketplace",
      text: "Find poultry feeds, supplements and feeding schedules."
    },
    {
      title: "Chicks & Hatcheries",
      text: "Buy chicks, eggs and incubators from trusted hatcheries."
    },
    {
      title: "Veterinary Services",
      text: "Access medicine, vaccination programs and poultry treatment."
    },
    {
      title: "Market for Chicken & Eggs",
      text: "Sell broilers, layers and eggs directly to customers."
    },
    {
      title: "Training & Tips",
      text: "Learn poultry farming best practices and management."
    }
  ]

  return (
    <div>
      <header className="hero">
        <h1>Kuku Poultry Farming App</h1>
        <p>
          A complete digital poultry farming ecosystem connecting farmers,
          feed suppliers, hatcheries, veterinary services and consumers.
        </p>
        <button>Install Kuku App</button>
      </header>

      <main className="container">
        <section>
          <h2>Complete Poultry Production Cycle</h2>
          <div className="grid">
            {services.map((item, index) => (
              <div className="card" key={index}>
                <h3>{item.title}</h3>
                <p>{item.text}</p>
              </div>
            ))}
          </div>
        </section>

        <section className="workflow">
          <h2>How Kuku Works</h2>
          <ol>
            <li>Farmers purchase chicks and incubators</li>
            <li>Feeds and equipment are supplied through the platform</li>
            <li>Veterinary medicine and vaccination services are provided</li>
            <li>Farmers raise poultry using farming guidance</li>
            <li>Chicken and eggs are sold directly to buyers and consumers</li>
          </ol>
        </section>

        <section className="about">
          <h2>About Kuku</h2>
          <p>
            Kuku is a cross-platform poultry farming application designed to
            improve poultry business management and market accessibility.
          </p>
        </section>
      </main>
    </div>
  )
}