# Kuku Poultry Farming App

Ready for deployment on Vercel.

Features:
- Poultry farming marketplace
- Feed suppliers
- Hatcheries and incubators
- Veterinary services
- Buyers market
- Mobile and desktop support